# CabbageClock
![CabbageClock](https://raw.githubusercontent.com/kazukazuprogram/Clock/master/icon/cabbage.png "icon")
## 0.1.0 Released!!!  
---
#### Major changes
 - Add restart
 - Avoiding an error when the window is closed<
